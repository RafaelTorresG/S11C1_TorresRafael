#Ejercicio 1: Cree un repositorio llamado ApellidoNombreS11C1cpp. En este repositorio deben estar todos los codigos que debe entregar al final de la clase. la entrega debe ser un directorio comprimido ApellidoNombreS11C1cpp.zip que usted debe subir a sicua y el enlace de GitHub con el repositorio correspondiente.

#programa 1: Haga un programa que Imprima "hola mundo". llamelo holamundo.cpp
print ("hello world")

#programa 2: Haga un programa que defina dos variables, una entera y una flotante e imprima el producto de las dos. llamelo producto.cpp
a=2
b=3.0
c=a*b
print("el producto de a por b es: ",c)

# programa 3: Haga un programa que calcule el factorial de un numero n. Tome n=7 como ejemplo. llamelo factorial.cpp. Que pasa si toma n=77?

# programa 4: Haga un programa que imprime todos los numeros entre 0 y 100 que sean divisibles por tres y NO sean divisibles por 5. Llamelo div3No5.cpp

# programa 5: repita el programa de factorial, pero ahora permita que el usuario ingrese el valor de n. llamelo factorial_inter.cpp

# Programa n>5: Traduzca algunos de sus codigos de python a cpp: derivadas, integrales y MCMC. Para esto debe mirar antes los tutoriales cuyos enlaces estan en Sicua. 




